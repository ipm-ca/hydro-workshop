void RotateSet   (int, int, int, int);
void RotateVector(double *, int);
void RotateBoundaryOld (const Data *, RBox *, int, Grid *);
void RotateBoundary (double ***, RBox *, int);
double RotateGet_ta(void);
double RotateGet_tb(void);

