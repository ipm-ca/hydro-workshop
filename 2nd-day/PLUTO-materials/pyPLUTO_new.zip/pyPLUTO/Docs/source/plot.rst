.. _plot:

.. autofunction:: pyPLUTO.Image.plot

|

----

.. This is a comment to prevent the document from ending with a transition.
