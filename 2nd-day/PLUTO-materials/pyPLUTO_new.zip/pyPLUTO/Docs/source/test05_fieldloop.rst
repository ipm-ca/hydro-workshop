.. _test05_fieldloop:

Test 05 - MHD Field loop test
=============================



  .. image:: ../../Tests/test05_fieldloop.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test05_fieldloop.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
