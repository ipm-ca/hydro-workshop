.. _examples:

Examples with PyPLUTO
=====================

.. toctree::

  test01_sod
  test02_ot
  test03_rti
  test04_rotor
  test05_fieldloop
  test06_diskplanet
  test07_khi
  test08_torus
  test09_blast
  test10_riemann2d
  test11_crxpoint
  test12_riemannlp
  test13_flowpastcyl

|

----

.. This is a comment to prevent the document from ending with a transition.
