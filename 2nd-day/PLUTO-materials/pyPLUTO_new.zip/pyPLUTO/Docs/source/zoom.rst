.. _zoom:

.. autofunction:: pyPLUTO.Image.zoom

|

----

.. This is a comment to prevent the document from ending with a transition.
