.. _test04_rotor:

Test 04 - MHD Rotor test
========================

.. image:: ../../Tests/test04_rotor.png
   :align: center
   :width: 600px

.. literalinclude :: ../../Tests/test04_rotor.py
   :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
