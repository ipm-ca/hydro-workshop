.. _test06_diskplanet:

Test 06 - HD Disk planet test
=============================


  .. image:: ../../Tests/test06_diskplanet.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test06_diskplanet.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
