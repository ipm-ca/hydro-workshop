.. _spectrum:

.. autofunction:: pyPLUTO.LoadPart.spectrum

|

----

.. This is a comment to prevent the document from ending with a transition.
