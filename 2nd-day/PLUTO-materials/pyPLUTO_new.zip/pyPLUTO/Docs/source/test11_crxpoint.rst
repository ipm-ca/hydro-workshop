.. _test11_xpoint:

Test 11 - Particles CR Xpoint test
==================================


  .. image:: ../../Tests/test11_xpoint.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test11_xpoint.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
