.. _legend:

.. autofunction:: pyPLUTO.Image.legend

|

----

.. This is a comment to prevent the document from ending with a transition.
