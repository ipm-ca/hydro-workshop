.. _test03_rti:

Test 03 - MHD Rayleigh-Taylor instability
=========================================


  .. image:: ../../Tests/test03_rti.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test03_rti.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
