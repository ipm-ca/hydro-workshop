.. _test07_khi:

Test 07 - RMHD Kelvin-Helmholtz instability test
================================================


  .. image:: ../../Tests/test07_khi.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test07_khi.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
