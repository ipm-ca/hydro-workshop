.. _test08_torus:

Test 08 - MHD Torus test
========================


  .. image:: ../../Tests/test08_torus.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test08_torus.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
