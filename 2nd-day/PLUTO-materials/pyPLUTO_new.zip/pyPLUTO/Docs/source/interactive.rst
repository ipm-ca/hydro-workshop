.. _interactive:

.. autofunction:: pyPLUTO.Image.interactive

|

----

.. This is a comment to prevent the document from ending with a transition.
