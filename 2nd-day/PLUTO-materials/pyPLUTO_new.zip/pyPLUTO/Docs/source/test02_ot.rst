.. _test02_ot:

Test 02 - MHD Orszag-Tang vortex
================================


  .. image:: ../../Tests/test02_ot.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test02_ot.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
