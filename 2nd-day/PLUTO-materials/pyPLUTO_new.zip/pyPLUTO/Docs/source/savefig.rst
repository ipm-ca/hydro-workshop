.. _savefig:

.. autofunction:: pyPLUTO.Image.savefig

|

----

.. This is a comment to prevent the document from ending with a transition.
