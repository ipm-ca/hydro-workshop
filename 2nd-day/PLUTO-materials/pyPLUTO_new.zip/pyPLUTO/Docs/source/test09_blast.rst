.. _test09_blast:

Test 09 - MHD Blast test
========================


  .. image:: ../../Tests/test09_blast.png
     :align: center
     :width: 600px

  .. literalinclude :: ../../Tests/test09_blast.py
     :language: python

|

----

.. This is a comment to prevent the document from ending with a transition.
