.. _create_axes:

.. autofunction:: pyPLUTO.Image.create_axes

|

----

.. This is a comment to prevent the document from ending with a transition.
