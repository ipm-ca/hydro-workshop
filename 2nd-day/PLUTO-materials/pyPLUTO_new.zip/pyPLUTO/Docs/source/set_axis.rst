.. _set_axis:

.. autofunction:: pyPLUTO.Image.set_axis

|

----

.. This is a comment to prevent the document from ending with a transition.
