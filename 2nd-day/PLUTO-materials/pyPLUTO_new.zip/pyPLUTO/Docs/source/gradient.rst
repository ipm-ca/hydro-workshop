.. _gradient:

.. autofunction:: pyPLUTO.Load.gradient

|

----

.. This is a comment to prevent the document from ending with a transition.
