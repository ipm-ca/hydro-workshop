import os
import sys
import numpy as np
import matplotlib.pyplot as plt
import pyPLUTO as pp

D = pp.Load(1)
I = pp.Image(figsize = [7,5])
time_label = fr'Sod shock tube at time {D.ntime}'

# Plotting the data
I.plot(D.x1, D.rho, label = r'$\rho$',
       title = time_label,
       xtitle = '$x$',
       xrange = [0.0,1.0],
       yrange = [-0.05,1.05],
       legpos = 0)

I.plot(D.x1, D.prs, label = r'$p$')
I.plot(D.x1, D.vx1, label = r'$v_x$')
plt.show()

