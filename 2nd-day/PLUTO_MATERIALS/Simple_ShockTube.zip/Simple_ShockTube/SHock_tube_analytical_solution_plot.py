import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

# Initial conditions: [density, velocity, pressure]
rho_L, u_L, p_L = 1.0, 0.0, 1.0
rho_R, u_R, p_R = 0.125, 0.0, 0.1
gamma = 1.4  # Ratio of specific heats

# Position and time
x = np.linspace(-1, 1, 500)
t = 0.2  # Time at which to evaluate the solution
x0 = 0.0  # Initial location of the discontinuity

def sound_speed(rho, p):
    return np.sqrt(gamma * p / rho)

def pressure_function(p, *args):
    rho_L, u_L, p_L, rho_R, u_R, p_R = args
    if p > p_L:
        f_L = (p - p_L) * np.sqrt((2 / ((gamma + 1) * rho_L)) / (p + (gamma - 1) * p_L / (gamma + 1)))
    else:
        f_L = (2 * sound_speed(rho_L, p_L) / (gamma - 1)) * ((p / p_L)**((gamma - 1) / (2 * gamma)) - 1)

    if p > p_R:
        f_R = (p - p_R) * np.sqrt((2 / ((gamma + 1) * rho_R)) / (p + (gamma - 1) * p_R / (gamma + 1)))
    else:
        f_R = (2 * sound_speed(rho_R, p_R) / (gamma - 1)) * ((p / p_R)**((gamma - 1) / (2 * gamma)) - 1)

    return f_L + f_R + u_R - u_L

# Solve for pressure in the star region
p_star_guess = 0.5 * (p_L + p_R)
p_star = fsolve(pressure_function, p_star_guess, args=(rho_L, u_L, p_L, rho_R, u_R, p_R))[0]

# Compute velocity in the star region
def velocity_star(p):
    if p > p_L:
        f_L = (p - p_L) * np.sqrt((2 / ((gamma + 1) * rho_L)) / (p + (gamma - 1) * p_L / (gamma + 1)))
    else:
        f_L = (2 * sound_speed(rho_L, p_L) / (gamma - 1)) * ((p / p_L)**((gamma - 1) / (2 * gamma)) - 1)
    return u_L - f_L

u_star = velocity_star(p_star)

# Speeds of waves
c_L = sound_speed(rho_L, p_L)
c_R = sound_speed(rho_R, p_R)

# Compute post-shock densities
def post_shock_density(p, rho, p_init):
    if p > p_init:
        return rho * ((p / p_init + (gamma - 1) / (gamma + 1)) /
                      ((gamma - 1) / (gamma + 1) * p / p_init + 1))
    else:
        return rho * (p / p_init) ** (1 / gamma)

rho_star_L = post_shock_density(p_star, rho_L, p_L)
rho_star_R = post_shock_density(p_star, rho_R, p_R)

# Characteristic speeds
shock_speed = u_star + c_R * np.sqrt((gamma + 1) / (2 * gamma) * (p_star / p_R - 1) + 1)
contact_speed = u_star
rarefaction_head = u_L - c_L
rarefaction_tail = u_star - sound_speed(rho_star_L, p_star)

# Build the solution
rho, u, p = np.zeros_like(x), np.zeros_like(x), np.zeros_like(x)

for i, xi in enumerate(x):
    xi_t = (xi - x0) / t
    if xi_t < rarefaction_head:
        rho[i], u[i], p[i] = rho_L, u_L, p_L
    elif rarefaction_head <= xi_t < rarefaction_tail:
        u[i] = (2 / (gamma + 1)) * (c_L + (xi_t - u_L))
        c = c_L - (gamma - 1) / 2 * (u[i] - u_L)
        rho[i] = rho_L * (c / c_L) ** (2 / (gamma - 1))
        p[i] = p_L * (c / c_L) ** (2 * gamma / (gamma - 1))
    elif rarefaction_tail <= xi_t < contact_speed:
        rho[i], u[i], p[i] = rho_star_L, u_star, p_star
    elif contact_speed <= xi_t < shock_speed:
        rho[i], u[i], p[i] = rho_star_R, u_star, p_star
    else:
        rho[i], u[i], p[i] = rho_R, u_R, p_R

# Plotting
plt.figure(figsize=(12, 8))
plt.subplot(3, 1, 1)
plt.plot(x, rho)
plt.ylabel('Density')

plt.subplot(3, 1, 2)
plt.plot(x, u)
plt.ylabel('Velocity')

plt.subplot(3, 1, 3)
plt.plot(x, p)
plt.ylabel('Pressure')
plt.xlabel('x')

plt.suptitle('Sod Shock Tube: Analytical Solution at t = {:.2f}'.format(t))
plt.tight_layout()
plt.show()




