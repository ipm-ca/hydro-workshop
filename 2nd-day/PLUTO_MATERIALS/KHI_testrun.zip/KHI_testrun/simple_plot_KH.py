import os
import sys
import pyPLUTO as pp
import os
import numpy   as np

# Creating the path for the data directory
#plutodir = os.environ['PLUTO_DIR']
wdir   = '.'

# Loading the data into a pload object D
D = pp.Load(8)

# Creating the image and the subplot axes (to have two secondary plots)
I = pp.Image(figsize = [10,10],
        suptitle = 'Test 02- Kelvin-Helmholtz instability test HD')
 
# Plotting the data
I.display((D.rho), x1 = D.x1, x2 = D.x2,
                            title = 'rho',
                           cmap = 'hot',
                           shading = 'gouraud',
                          #  vmin=1e-6,
                          #  vmax=1e-5,
                           xtitle = r'$x$',
                           ytitle = r'$y$')
I.colorbar( )
# Find and plot the field lines
pp.show()


