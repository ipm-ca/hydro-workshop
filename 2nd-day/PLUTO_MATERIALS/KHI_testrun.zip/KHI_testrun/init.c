/* ///////////////////////////////////////////////////////////////////// */
/*!
  \file
  \brief Relativistic magnetized Kelvin-Helmholtz problem.

  Implements the initial condition for a KH in HD regyme
  2D Cartesian coordinates as in section 
*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *v, double x1, double x2, double x3)
/*
 *
 *
 *
 *********************************************************************** */
{
 
  double y0 ;
  double rho, vx, vy, prs;
  double x,y, kx, alpha, beta;
  double arg, eps;
  
  x = x1;
  y = x2;
  kx    = 2.0*CONST_PI*x1;
  alpha = 1.0/100.0;
  beta  = 1.0/10.0;
  arg = y*y/(beta*beta);
  eps = 0.1*g_inputParam[VEL0];

  y0=0.;
  
 if (y < y0) {
    rho = 1.0;
    vx=-0.5;
    //*tanh(y/alpha);
  } else {
    rho = 2.0;
    vx= 0.5;
    //*tanh(y/alpha);;
  }
  
  vy = eps*0.5*(sin(kx) - sin(-kx))*exp(-arg);
  prs = 20;

  v[RHO] = rho;
  v[VX1] = vx;
  v[VX2] = vy;
  v[PRS] = prs;


  
  
  
}


/* ********************************************************************* */
void InitDomain (Data *d, Grid *grid)
/*! 
 * Assign initial condition by looping over the computational domain.
 * Called after the usual Init() function to assign initial conditions
 * on primitive variables.
 * Value assigned here will overwrite those prescribed during Init().
 *
 *
 *********************************************************************** */
{
}

/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/* 
 *
 *
 *********************************************************************** */
{

}
/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid) 
/*
 *
 *
 *********************************************************************** */
{ 
}
