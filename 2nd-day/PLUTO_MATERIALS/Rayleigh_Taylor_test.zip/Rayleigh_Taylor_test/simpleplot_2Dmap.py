import os
import sys
import numpy as np
import matplotlib.pyplot as plt
import pyPLUTO as pp
D = pp.Load(2)
#I = pp.Image().plot(D.x1,D.rho[:,0,10])
I = pp.Image(figsize = [5,5],suptitle = 'Test RTI')
I.display(np.log10(D.rho), x1 = D.x1, x2 = D.x2)
pp.show()
