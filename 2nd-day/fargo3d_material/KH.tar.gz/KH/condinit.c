#include "fargo3d.h"

void Init() {
  int i,j,k;
  real Q1, Q2, Q3;
  
  real* v1 = Vy->field_cpu;
  real* v2 = Vz->field_cpu;
  
  real* rho = Density->field_cpu;
  real* e = Energy->field_cpu;
  
  if(Nz == 1) {
    real* v1 = Vx->field_cpu;
    real* v2 = Vy->field_cpu;
  }
  if(Ny == 1) {
    real* v1 = Vx->field_cpu;
    real* v2 = Vz->field_cpu;
  }
  if(Nx == 1) {
    real* v1 = Vy->field_cpu;
    real* v2 = Vz->field_cpu;
  }
 real phase = 1;
 real kz = 2 * M_PI/phase;

#ifdef Z
  for (k=0; k<Nz+2*NGHZ; k++) {
#endif
#ifdef Y
    for (j=0; j<Ny+2*NGHY; j++) {
#endif
#ifdef X
      for (i=0; i<Nx; i++) {
#endif
		if(Nz == 1) {
			Q1 = (Xmed(i)-XMIN)/(XMAX-XMIN);
			Q2 = (Ymed(j)-YMIN)/(YMAX-YMIN);
			Q3 = (YMAX+YMIN)/2.;
		}
		if(Ny == 1) {
			Q1 = (Xmed(i)-XMIN)/(XMAX-XMIN);
			Q2 = (Zmed(k)-ZMIN)/(ZMAX-ZMIN);
			Q3 = (ZMAX+ZMIN)/2.;
		}
		if(Nx == 1) {
			Q1 = (Ymed(j)-YMIN)/(YMAX-YMIN);
			Q2 = (Zmed(k)-ZMIN)/(ZMAX-ZMIN);
			Q3 = (ZMAX+ZMIN)/2.;
		}
		
		if (Q2 < 0.5){
			rho[l] =  1;
			v2[l] = 0.5 * cos(kz * (Ymed(j)-phase/2)) * exp(kz*(Zmed(k)-Q3));
			v1[l] = 3.0 ;
		} else {
			rho[l] = 2;
			v2[l] = 0.5 * cos(kz * (Ymed(j)-phase/2)) * exp(-kz*(Zmed(k)-Q3));
			v1[l] = -3.0;
		}
#ifdef ADIABATIC
        e[l] = .05/(GAMMA-1.0);
#endif		
#ifdef X
      }
#endif
#ifdef Y
    }
#endif
#ifdef Z
  }
#endif
}

void CondInit() {
   Fluids[0] = CreateFluid("gas",GAS);
   SelectFluid(0);
   Init();
}
