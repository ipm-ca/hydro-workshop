import yt

# load the dataset
i =1
while i <= 20:
    print(i)
    if i<10:
        nam="../../output_0000%i/info_0000%i.txt" %(i,i)
    else:
        nam="../../output_000%i/info_000%i.txt" %(i,i)
 
    print(nam)
    
    # Load the dataset.
    ds1 = yt.load(nam)
    
    # Create gas density slices
    p2 = yt.SlicePlot(ds1, "z", ["density" ])   
    #p2 = yt.SlicePlot(ds1, "z", ["temperature" ]) 
    #p2.set_axes_unit('pc')
    #p2.annotate_velocity()
    p2.annotate_timestamp(corner='upper_left') 
    #p.zoom(1)    
    #p2.annotate_grids()
    
    #save result
    p2.save()
    
    
    i += 1


