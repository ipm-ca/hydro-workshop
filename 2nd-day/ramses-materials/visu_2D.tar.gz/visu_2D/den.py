import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import LogNorm
import numpy as np
plt.rcParams['text.usetex'] = True

time = np.loadtxt('time.txt')
print(time)
x, y, d = np.loadtxt('den',unpack=True)
unique_x = np.unique(x)
unique_y = np.unique(y)
density = d.reshape(len(unique_x), len(unique_y))
fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(6,4.7))
ax1= plt.subplot(1,1 ,1)
im = ax1.imshow(density.T, extent=(np.amin(x), np.amax(x), np.amin(y), np.amax(y)), cmap=cm.viridis)
axz=plt.colorbar(im, ax=ax1)
axz.set_label(r'Density\ [${\rm g/cm^{3}}$]') 
tim = str(time)
titl = 't='+tim+' s'
plt.title(titl)
#axz.set_xlabel('x')
#axz.set_ylabel('y')
fig.savefig('out.jpeg')


#plt.show()

